﻿param(
    [string]$ZipPath = "",
    [string]$TargetDir = ""
)
# ============================================================
#  嘉立创EDA自动化 · 自动安装脚本
#  用法: 由AI agent调用, 传入:
#    -ZipPath    安装包 lceda-eda-auto-kit.zip 的路径
#    -TargetDir  AI技能目录(把 skills\ 下的两个技能装进去)
#  自动完成: 解压 -> 拷技能 -> 检查/安装Node.js -> 起桥 -> 验证
# ============================================================
$ErrorActionPreference = "Stop"
chcp 65001 > $null

if (-not $ZipPath -or -not (Test-Path $ZipPath)) {
    Write-Host "[ERROR] 找不到安装包: $ZipPath" -ForegroundColor Red
    Write-Host "请把 lceda-eda-auto-kit.zip 的完整路径传给我。"
    exit 1
}
if (-not $TargetDir) {
    Write-Host "[ERROR] 未指定技能目标目录 -TargetDir" -ForegroundColor Red
    exit 1
}

$tmp = Join-Path ([IO.Path]::GetTempPath()) ("lceda_install_" + [Guid]::NewGuid().ToString("N"))
Write-Host "[1/5] 解压安装包..." -ForegroundColor Cyan
New-Item -ItemType Directory -Path $tmp -Force | Out-Null
Expand-Archive -Path $ZipPath -DestinationPath $tmp -Force

$srcSkills = Join-Path $tmp "skills"
if (-not (Test-Path $srcSkills)) {
    # 兼容: 包里可能多包了一层目录
    $inner = Get-ChildItem $tmp -Directory | Select-Object -First 1
    $srcSkills = Join-Path $inner.FullName "skills"
    if (-not (Test-Path $srcSkills)) { Write-Host "[ERROR] 包内未找到 skills 目录" -ForegroundColor Red; exit 1 }
}

Write-Host "[2/5] 拷贝技能到: $TargetDir" -ForegroundColor Cyan
New-Item -ItemType Directory -Path $TargetDir -Force | Out-Null
foreach ($name in @("easyeda-api", "lceda-symbol-generator")) {
    $s = Join-Path $srcSkills $name
    $d = Join-Path $TargetDir $name
    if (Test-Path $s) {
        if (Test-Path $d) { Remove-Item $d -Recurse -Force }
        robocopy $s $d /E /NFL /NDL /NJH /NJS /R:1 | Out-Null
        Write-Host ("  [OK] " + $name)
    } else {
        Write-Host ("  [WARN] 包内无 " + $name)
    }
}

Write-Host "[3/5] 检查 Node.js..." -ForegroundColor Cyan
$nodeOk = $false
try { $nv = (node --version 2>&1); if ($nv -match "v\d+") { $nodeOk = $true; Write-Host ("  [OK] Node.js " + $nv) } } catch {}
if (-not $nodeOk) {
    Write-Host "  Node.js 未安装, 正在通过 winget 静默安装 LTS..." -ForegroundColor Yellow
    winget install --id OpenJS.NodeJS.LTS --silent --accept-package-agreements --accept-source-agreements | Out-Null
    # 刷新PATH后验证
    $env:Path = [Environment]::GetEnvironmentVariable("Path", "Machine") + ";" + [Environment]::GetEnvironmentVariable("Path", "User")
    try { $nv = (node --version 2>&1); if ($nv -match "v\d+") { $nodeOk = $true; Write-Host ("  [OK] 安装完成 Node.js " + $nv) } } catch {}
    if (-not $nodeOk) { Write-Host "[ERROR] Node.js 安装失败, 请手动安装 https://nodejs.org" -ForegroundColor Red; exit 1 }
}

Write-Host "[4/5] 启动桥接服务器..." -ForegroundColor Cyan
$bridgeDir = Join-Path $TargetDir "easyeda-api"
$found = $false
foreach ($p in 49620..49629) {
    try { $r = curl.exe -s --max-time 1 "http://127.0.0.1:${p}/health"; if ($r -match "easyeda-bridge") { $found = $true; $bridgePort = $p; break } } catch {}
}
if ($found) {
    Write-Host ("  [OK] 桥已在运行 (端口 " + $bridgePort + ")")
} else {
    if (-not (Test-Path (Join-Path $bridgeDir "node_modules\ws"))) {
        Write-Host "  首次运行, 安装依赖..." -ForegroundColor Yellow
        Push-Location $bridgeDir; npm install --no-audit --no-fund | Out-Null; Pop-Location
    }
    Start-Process -FilePath "node" -ArgumentList ('"' + (Join-Path $bridgeDir "scripts\bridge-server.mjs") + '"') -WorkingDirectory $bridgeDir -WindowStyle Hidden
    Start-Sleep -Seconds 4
    Write-Host "  [OK] 桥已启动"
}

Write-Host "[5/5] 验证连接..." -ForegroundColor Cyan
foreach ($p in 49620..49629) {
    try { $r = curl.exe -s --max-time 2 "http://127.0.0.1:${p}/health"; if ($r -match "easyeda-bridge") { Write-Host ("  状态: " + $r); break } } catch {}
}

Write-Host ""
Write-Host "============================================" -ForegroundColor Green
Write-Host "  自动安装完成!" -ForegroundColor Green
Write-Host "  技能已装好 + 桥已启动。" -ForegroundColor Green
Write-Host "  edaConnected:true  = 直接可用" -ForegroundColor Green
Write-Host "  edaConnected:false = 在EDA顶部点 API Gateway -> Reconnect" -ForegroundColor Yellow
Write-Host "============================================" -ForegroundColor Green
Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
