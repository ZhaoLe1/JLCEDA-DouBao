# TPCB\_LayersOfInner type

Inner layers

## Signature

```typescript
type TPCB_LayersOfInner
	= | EPCB_LayerId.INNER_1
		| EPCB_LayerId.INNER_2
		| EPCB_LayerId.INNER_3
		| EPCB_LayerId.INNER_4
		| EPCB_LayerId.INNER_5
		| EPCB_LayerId.INNER_6
		| EPCB_LayerId.INNER_7
		| EPCB_LayerId.INNER_8
		| EPCB_LayerId.INNER_9
		| EPCB_LayerId.INNER_10
		| EPCB_LayerId.INNER_11
		| EPCB_LayerId.INNER_12
		| EPCB_LayerId.INNER_13
		| EPCB_LayerId.INNER_14
		| EPCB_LayerId.INNER_15
		| EPCB_LayerId.INNER_16
		| EPCB_LayerId.INNER_17
		| EPCB_LayerId.INNER_18
		| EPCB_LayerId.INNER_19
		| EPCB_LayerId.INNER_20
		| EPCB_LayerId.INNER_21
		| EPCB_LayerId.INNER_22
		| EPCB_LayerId.INNER_23
		| EPCB_LayerId.INNER_24
		| EPCB_LayerId.INNER_25
		| EPCB_LayerId.INNER_26
		| EPCB_LayerId.INNER_27
		| EPCB_LayerId.INNER_28
		| EPCB_LayerId.INNER_29
		| EPCB_LayerId.INNER_30;
```
## References

[EPCB\_LayerId.INNER\_1](../enums/EPCB_LayerId.md)<!-- -->, [EPCB\_LayerId.INNER\_2](../enums/EPCB_LayerId.md)<!-- -->, [EPCB\_LayerId.INNER\_3](../enums/EPCB_LayerId.md)<!-- -->, [EPCB\_LayerId.INNER\_4](../enums/EPCB_LayerId.md)<!-- -->, [EPCB\_LayerId.INNER\_5](../enums/EPCB_LayerId.md)<!-- -->, [EPCB\_LayerId.INNER\_6](../enums/EPCB_LayerId.md)<!-- -->, [EPCB\_LayerId.INNER\_7](../enums/EPCB_LayerId.md)<!-- -->, [EPCB\_LayerId.INNER\_8](../enums/EPCB_LayerId.md)<!-- -->, [EPCB\_LayerId.INNER\_9](../enums/EPCB_LayerId.md)<!-- -->, [EPCB\_LayerId.INNER\_10](../enums/EPCB_LayerId.md)<!-- -->, [EPCB\_LayerId.INNER\_11](../enums/EPCB_LayerId.md)<!-- -->, [EPCB\_LayerId.INNER\_12](../enums/EPCB_LayerId.md)<!-- -->, [EPCB\_LayerId.INNER\_13](../enums/EPCB_LayerId.md)<!-- -->, [EPCB\_LayerId.INNER\_14](../enums/EPCB_LayerId.md)<!-- -->, [EPCB\_LayerId.INNER\_15](../enums/EPCB_LayerId.md)<!-- -->, [EPCB\_LayerId.INNER\_16](../enums/EPCB_LayerId.md)<!-- -->, [EPCB\_LayerId.INNER\_17](../enums/EPCB_LayerId.md)<!-- -->, [EPCB\_LayerId.INNER\_18](../enums/EPCB_LayerId.md)<!-- -->, [EPCB\_LayerId.INNER\_19](../enums/EPCB_LayerId.md)<!-- -->, [EPCB\_LayerId.INNER\_20](../enums/EPCB_LayerId.md)<!-- -->, [EPCB\_LayerId.INNER\_21](../enums/EPCB_LayerId.md)<!-- -->, [EPCB\_LayerId.INNER\_22](../enums/EPCB_LayerId.md)<!-- -->, [EPCB\_LayerId.INNER\_23](../enums/EPCB_LayerId.md)<!-- -->, [EPCB\_LayerId.INNER\_24](../enums/EPCB_LayerId.md)<!-- -->, [EPCB\_LayerId.INNER\_25](../enums/EPCB_LayerId.md)<!-- -->, [EPCB\_LayerId.INNER\_26](../enums/EPCB_LayerId.md)<!-- -->, [EPCB\_LayerId.INNER\_27](../enums/EPCB_LayerId.md)<!-- -->, [EPCB\_LayerId.INNER\_28](../enums/EPCB_LayerId.md)<!-- -->, [EPCB\_LayerId.INNER\_29](../enums/EPCB_LayerId.md)<!-- -->, [EPCB\_LayerId.INNER\_30](../enums/EPCB_LayerId.md)