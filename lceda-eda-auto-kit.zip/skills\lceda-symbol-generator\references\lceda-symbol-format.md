# 嘉立创EDA专业版 原理图符号格式参考

本文件记录经**官方文档与官方范例工程(泰山派1F .epro2/.epru)逐条核对**后确认的、
`lceda-symbol-generator` 技能所依赖的关键格式事实。生成符号时必须遵守这里的约定。

---

## 1. 坐标与单位约定

- 所有坐标、长度、大小统一使用 **0.01 inch** 为单位(100 = 1 inch)。
  示例: 引脚长度 20 = 0.2 inch(与"高级符号向导"默认一致)。
- 旋转角度以**逆时针为正**, 使用角度制(0/90/180/270)。
- 颜色用 `"#RRGGBB"`, 无颜色(默认)用 `null` 或 `""`。

## 2. 引脚方向(Side)与 rotation 对应关系

引脚图的 **position(x,y) 是远离封装体的那个连接端点**(焊线点);
引脚线从该端点向封装体方向延伸 `length` 长度。

| Side(向导) | 含义   | V3 rotation | 引脚指向    | 连接端点位置 |
|-----------|--------|-------------|------------|--------------|
| L         | 左边   | 0           | 向左(-x)   | x 为负, 最左 |
| T         | 上边   | 90          | 向上(+y)   | y 为正, 最上 |
| R         | 右边   | 180         | 向右(+x)   | x 为正, 最右 |
| B         | 下边   | 270         | 向下(-y)   | y 为负, 最下 |

> 该约定已从官方范例工程(左引脚 x=-65 rotation=0、右引脚 x=+65 rotation=180)验证无误。

## 3. 高级符号向导(工具 -> 高级符号向导) —— 保底导入路径

向导**导出 Excel 模板**, 用 Office/WPS 编辑后点"导入"即可按模板自动生成符号
(自动摆放引脚并生成矩形封装体)。模板列(顺序必须一致):

```
Part | Side | Order | Pin Name | Pin Type | Pin Number | Pin Shape
```

| 列        | 取值说明 |
|-----------|---------|
| Part      | 部件/子库名(多单元器件填写区分, 单单元留空) |
| Side      | L / T / R / B(左/上/右/下) |
| Order     | 同方向上引脚的位置序号(从1起) |
| Pin Name  | 引脚名称, 如 VCC、SCL、PA0 |
| Pin Type  | 引脚类型, 见下表 |
| Pin Number| 引脚编号(封装脚位号), 如 1、2、10 |
| Pin Shape | 引脚附加形状, 见下表 |

**Pin Type 枚举**(向导与 V3 文件 "Pin Type" 共用同一字符串):

`IN`(输入) `OUT`(输出) `BI`(双向) `Passive`(无源) `Open Collector`(开集电极)
`Open Emitter`(开发射极) `Power`(电源) `Ground`(地) `HIZ`(高阻)
`Terminator`(信号终端) `Undefined`(无定义)

**Pin Shape 枚举**(向导用词 → V3 文件 `pinShape` 字符串):

| 向导用词           | V3 pinShape      |
|-------------------|------------------|
| None(无)          | `NONE`           |
| Inverted(反相)    | `INVERTED`       |
| Clock(时钟)       | `CLOCK`          |
| Inverted Clock    | `INVERTED_CLOCK` |
| DOT               | `DOT`            |

## 4. V3 符号文件(JSON-Lines)—— 进阶/自动化路径

专业版 V3 工程(epro2/epru)内部是 **JSON-Lines 日志**:
每一行是 `外层||内层|`, 外层供一致性框架(含 `type`/`id`/`ticket`), 内层为图元数据。

`generate_symbols.py` 生成的 `.json` 即这种格式, 结构如下(逐行):

| 行类型           | 内层关键字段 | 说明 |
|-----------------|-------------|------|
| DOCHEAD         | docType=SYMBOL, uuid, client | 文档头, 标识"这是符号文档" |
| CANVAS          | originX, originY | 画布配置 |
| PART            | BBOX, title | 子库(部件); 单部件 id 为 pid 前缀 |
| ATTR            | partId,parentId,key,value,... | 属性; 元件级 parentId 为空串 |
| PIN             | partId,x,y,length,rotation,pinShape | 引脚(见 §2/§5) |
| ATTR(引脚附属)  | parentId=引脚id, key=Pin Name/Number/Type | 引脚名/编号/类型 |
| RECT            | dotX1,dotY1,dotX2,dotY2 | 封装体矩形 |
| META            | title,description,tags,docType | 文档元数据 |

**符号类型编号(META.docType)**: `2`=普通器件(Part Symbol); 18=全局网络符号;
19=层次图网络导出; 20=图纸; 21=无电气; 22=短接符。

## 5. 引脚图元(PIN)真实字段

`generate_symbols.py` 输出的 PIN 行示例:

```
{"type":"PIN","ticket":6,"id":"e6"}||
{"partId":"pid...","groupId":"","locked":false,"zIndex":2,"display":true,
 "x":-40,"y":10,"length":20,"rotation":0,"color":null,"pinShape":"NONE"}|
```

- 使用 `x`/`y`(而非文档示例里的 positionX/positionY)—— 以官方范例工程实况为准。
- `groupId` 单部件为空串 `""`。
- `pinShape` 为字符串(`"NONE"` 等), 不是数字。
- 每个 PIN 之后必须跟三个 `parentId` 指向该引脚的 ATTR:
  `Pin Name`、`Pin Number`、`Pin Type`。

## 6. 器件数据输入格式(被 generate_symbols.py 解析)

扫描文件夹, 支持下列文件; 每个文件/表解析为一个器件:

- **Excel(.xlsx/.xls)/CSV/TSV**: 引脚表, 首行为表头。表头支持中文与英文同义词
  (引脚名称/Pin Name, 引脚编号/Pin Number, 引脚类型/Pin Type, 方向/Side,
   引脚形状/Pin Shape, 部件/Part, 序号/Order, 元件名/Device 等)。
  元件名缺省时取文件名。
- **JSON**: 对象或对象数组, 形如
  `{"name":"芯片名","description":"描述","pins":[{"name","number","ptype","side","shape","part"}]}`。
- **Markdown/文本(.md/.txt)**: 管道表格(| a | b |)。

> 数据手册(PDF)中的引脚表解析不确定, 建议先用 doubao-pdf 等把引脚表提取成
> CSV/JSON 再交给本技能, 并人工核对后再生成。

## 7. 产物说明

输出目录 `lceda_symbol_output/` 下:

| 子目录        | 内容 |
|--------------|------|
| `wizard/`    | 每个器件一个 `.xlsx` —— **高级符号向导导入模板(保底路径)** |
| `symbol_json/`| 每个器件一个 `.json` —— V3 JSON-Lines 符号文件(进阶) |
| `preview/`   | 每个器件一个 `.svg` —— 符号排版预览图 |

**推荐使用流程**: 打开 `preview` 查看符号外观 → 在专业版中
`工具 -> 高级符号向导 -> 导入` 选 `wizard/*.xlsx`, 向导自动生成符号;
再对新符号补绑定封装/3D 模型即可。
