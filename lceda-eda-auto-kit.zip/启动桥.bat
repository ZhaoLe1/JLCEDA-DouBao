@echo off
title LCEDA Auto - Bridge Launcher
echo ============================================
echo   LCEDA Auto - One-click Bridge Launcher
echo ============================================
echo.

cd /d "%~dp0skills\easyeda-api"

REM ---------- check Node.js ----------
where node >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Node.js not found.
    echo Install Node.js 22+ from https://nodejs.org then run again.
    echo.
    pause
    exit /b 1
)
node --version

REM ---------- ensure ws is installed ----------
if not exist node_modules\ws (
    echo Installing dependencies via npm, please wait...
    call npm install --no-audit --no-fund
)

REM ---------- check if bridge already running ----------
echo.
echo Checking bridge status on port 49620...
curl -s --max-time 2 http://127.0.0.1:49620/health >nul 2>&1
if not errorlevel 1 (
    echo [OK] Bridge is already running.
) else (
    echo Starting bridge server in background...
    start "" node scripts\bridge-server.mjs
    timeout /t 3 /nobreak >nul
)

REM ---------- show status ----------
echo.
echo ---- Connection status ----
curl -s --max-time 3 http://127.0.0.1:49620/health
echo.
echo.
echo If edaConnected:true   - connected. Ready to use.
echo If edaConnected:false  - open EDA, click "API Gateway - Reconnect".
echo.
echo You may close this window; the bridge keeps running in background.
echo.
pause
