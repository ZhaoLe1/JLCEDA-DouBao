@echo off
chcp 65001 >nul
title 检查桥接连接状态
echo ---- 检查桥接服务器与EDA连接状态 ----
echo.
curl -s --max-time 3 http://127.0.0.1:49620/health
echo.
echo.
echo 说明:
echo   edaConnected:true   = 已连上EDA，可以直接让AI操作了
echo   edaConnected:false  = 未连上，请在EDA顶部点 "API Gateway -> Reconnect"
echo.
pause
