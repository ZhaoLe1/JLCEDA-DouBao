#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
嘉立创EDA专业版 —— 原理图元件符号自动生成器
================================================
扫描一个文件夹里的器件数据文件(Excel/CSV/JSON/Markdown 引脚表), 解析出元件名与引脚信息,
自动排版引脚位置, 并输出两类产物:

  1) 高级符号向导导入模板 (*.xlsx)    —— 保底、官方原生支持的路径
       顶部菜单 -> 工具 -> 高级符号向导 -> 导入 该模板即可自动生成符号
       (该向导自动摆放引脚并生成矩形封装体, 无需手工布线)

  2) V3 符号定义文件 (*.json, JSON-Lines) —— 进阶/自动化路径
       与嘉立创EDA专业版 V3 文件格式一致(内含 DOCHEAD/CANVAS/PART/ATTR/PIN/RECT/META),
       可注入工程库(epro2/epru)或用于后续批量处理

依赖: openpyxl (pip install openpyxl)。若环境没有, 脚本会尝试自动安装。

用法:
    python generate_symbols.py <器件数据文件夹> [--out <输出目录>] [--pin-length <数值>]
    --out        输出目录, 默认在数据文件夹下新建 lceda_symbol_output
    --pin-length 引脚长度(0.01inch 单位), 默认 20 (=0.2inch, 与向导默认一致)
"""

import sys, os, json, csv, re, uuid, argparse, glob
from collections import OrderedDict

try:
    import openpyxl
except ImportError:
    os.system("python -m pip install openpyxl --quiet")
    import openpyxl
from openpyxl import Workbook
from openpyxl.utils import get_column_letter

# ---------------------------------------------------------------------------
# 常量: 嘉立创EDA专业版真实文件格式词汇表(经官方范例工程核对)
# ---------------------------------------------------------------------------

# 高级符号向导列(顺序必须一致): Part, Side, Order, Pin Name, Pin Type, Pin Number, Pin Shape
WIZARD_HEADER = ["Part", "Side", "Order", "Pin Name", "Pin Type", "Pin Number", "Pin Shape"]

# Side: L=左, T=上, R=右, B=下; 对应 V3 文件里的引脚 rotation
SIDE_TO_ROTATION = {"L": 0, "T": 90, "R": 180, "B": 270}

# 引脚类型(向导 / V3 "Pin Type" 共用同一字符串)
PIN_TYPES = ["IN", "OUT", "BI", "Passive", "Open Collector", "Open Emitter",
             "Power", "Ground", "HIZ", "Terminator", "Undefined"]

# 引脚形状: 向导用词 -> V3 文件 pinShape 字符串
SHAPE_WIZARD_TO_JSON = {
    "None": "NONE", "Inverted": "INVERTED", "Clock": "CLOCK",
    "Inverted Clock": "INVERTED_CLOCK", "DOT": "DOT",
}

# 引脚表表头中文/英文同义词映射(用于从任意引脚表解析)
HEADER_SYNONYMS = {
    "devname": ["元件名", "器件名", "符号名", "device", "component", "symbol"],
    "part":   ["part", "部件", "子库", "unit", "单元"],
    "side":   ["side", "方向", "方位", "side/dir", "dir"],
    "order":  ["order", "序号", "顺序", "排序", "no.", "order#"],
    "name":   ["pin name", "引脚名称", "脚名", "pin", "name"],
    "ptype":  ["pin type", "引脚类型", "类型", "type", "电气类型"],
    "number": ["pin number", "引脚编号", "编号", "脚位", "pin#", "number", "脚号"],
    "shape":  ["pin shape", "引脚形状", "形状", "shape"],
}


class Pin:
    """单个引脚"""
    def __init__(self, name="", number="", ptype="Passive", shape="None",
                 side="", part="", order=None):
        self.name = str(name).strip()
        self.number = str(number).strip()
        self.ptype = str(ptype).strip() or "Passive"
        self.shape = str(shape).strip() or "None"
        self.side = str(side).strip().upper()[:1] if str(side).strip() else ""
        self.part = str(part).strip()
        self.order = order
        self.x = None
        self.y = None
        self.rotation = None

    @property
    def json_shape(self):
        return SHAPE_WIZARD_TO_JSON.get(self.shape, "NONE")


class Device:
    """一个原理图元件(符号)"""
    def __init__(self, name="", description=""):
        self.name = str(name).strip() or "未命名元件"
        self.description = str(description).strip()
        self.pins = []

    def add_pin(self, pin):
        self.pins.append(pin)


# ---------------------------------------------------------------------------
# 1. 解析器件数据文件
# ---------------------------------------------------------------------------

def normalize_key(s):
    s = str(s).strip().lower().replace("_", " ").replace("-", " ")
    return re.sub(r"\s+", " ", s)


def match_header(col):
    """把任意表头列名映射到内部字段 key。
    策略: ①全字精确匹配(同义词集合内, 含中/英文); ②仅在"表头包含同义词"时做子串匹配,
    避免 'Part' 被误判成 'component'(器件名)。返回内部字段名, 找不到返回 None。"""
    key = normalize_key(col)
    # 第一遍: 精确匹配
    for field, syns in HEADER_SYNONYMS.items():
        for syn in syns:
            if key == normalize_key(syn):
                return field
    # 第二遍: 表头包含同义词(仅这一方向), 且同义词足够具体(>=2字符)避免误伤
    for field, syns in HEADER_SYNONYMS.items():
        for syn in syns:
            ns = normalize_key(syn)
            if len(ns) >= 2 and ns in key:
                return field
    return None


def build_mapping(headers):
    """根据表头行建立 列下标->字段 映射"""
    mapping = {}
    for idx, h in enumerate(headers):
        f = match_header(h)
        if f:
            mapping[idx] = f
    return mapping


def device_from_rows(rows, default_name="器件"):
    """从已映射的字典行列表生成 Device; rows: list[dict[field->value]]"""
    # 元件名: 优先专用"元件名"列, 否则用默认(通常是文件名)
    dev_name = default_name
    for r in rows:
        v = r.get("devname")
        if v and str(v).strip():
            dev_name = str(v).strip()
            break
    dev = Device(name=dev_name or "器件")
    for r in rows:
        p = Pin(
            name=r.get("name", ""), number=r.get("number", ""),
            ptype=r.get("ptype", "Passive"), shape=r.get("shape", "None"),
            side=r.get("side", ""), part=r.get("part", ""),
            order=int(r["order"]) if str(r.get("order", "")).strip().isdigit() else None,
        )
        if not p.name and not p.number:
            continue
        dev.add_pin(p)
    return dev


def read_csv(path):
    with open(path, "r", encoding="utf-8-sig", newline="") as f:
        reader = csv.reader(f)
        rows = list(reader)
    if not rows:
        return []
    headers = rows[0]
    mapping = build_mapping(headers)
    if not mapping:
        return []  # 无法识别为引脚表
    dict_rows = []
    for row in rows[1:]:
        d = {}
        for idx, fld in mapping.items():
            if idx < len(row):
                d[fld] = row[idx].strip()
        dict_rows.append(d)
    return dict_rows


def read_xlsx_sheet(path, sheet=None):
    wb = openpyxl.load_workbook(path, data_only=True)
    ws = wb[sheet] if sheet else wb.active
    rows = [[c.value if c.value is not None else "" for c in row] for row in ws.iter_rows()]
    if not rows:
        return []
    headers = [str(h) for h in rows[0]]
    mapping = build_mapping(headers)
    if not mapping:
        return []
    dict_rows = []
    for row in rows[1:]:
        d = {}
        for idx, fld in mapping.items():
            if idx < len(row) and row[idx] != "":
                d[fld] = str(row[idx]).strip()
        dict_rows.append(d)
    return dict_rows


def read_markdown_table(path):
    """解析 Markdown / 文本里的管道表格(| a | b |)与空白分隔表格"""
    with open(path, "r", encoding="utf-8-sig") as f:
        lines = f.readlines()
    pipe_rows = []
    for ln in lines:
        s = ln.strip()
        if s.startswith("|") and s.endswith("|") and "---" not in s:
            cells = [c.strip() for c in s.strip("|").split("|")]
            pipe_rows.append(cells)
    if pipe_rows:
        headers = pipe_rows[0]
        mapping = build_mapping(headers)
        if mapping:
            dict_rows = []
            for row in pipe_rows[1:]:
                if all(re.fullmatch(r":?-{2,}:?", c) for c in row):
                    continue
                d = {}
                for idx, fld in mapping.items():
                    if idx < len(row):
                        d[fld] = row[idx].strip()
                dict_rows.append(d)
            return dict_rows
    # 空白分隔表格
    dict_rows = []
    for ln in lines:
        s = ln.strip()
        if not s or s.startswith("#"):
            continue
        toks = re.split(r"\s{2,}|\t", s.strip())
        if len(toks) >= 3:
            dict_rows.append({})
    return dict_rows


def read_json(path):
    with open(path, "r", encoding="utf-8-sig") as f:
        data = json.load(f)
    devices = []
    if isinstance(data, dict):
        # 允许 { "name":..., "pins":[...] } 或 { "devices":[...] }
        if "devices" in data:
            data = data["devices"]
        else:
            data = [data]
    for item in data:
        if not isinstance(item, dict):
            continue
        dev = Device(name=item.get("name", item.get("title", "")),
                     description=item.get("description", ""))
        pins = item.get("pins", [])
        for p in pins:
            dev.add_pin(Pin(
                name=p.get("name", p.get("pinName", "")),
                number=p.get("number", p.get("pinNumber", "")),
                ptype=p.get("ptype", p.get("pinType", "Passive")),
                shape=p.get("shape", p.get("pinShape", "None")),
                side=p.get("side", ""),
                part=p.get("part", p.get("unit", "")),
                order=p.get("order"),
            ))
        if dev.pins:
            devices.append(dev)
    return devices


def parse_inputs(folder):
    """扫描文件夹, 返回 Device 列表(每个文件/表 -> 一个或多个器件)"""
    devices = []
    files = []
    for ext in ("*.csv", "*.tsv", "*.txt", "*.xlsx", "*.xls", "*.json", "*.md"):
        files.extend(glob.glob(os.path.join(folder, ext)))
    files = sorted(set(files), key=str.lower)
    for path in files:
        ext = os.path.splitext(path)[1].lower()
        base = os.path.splitext(os.path.basename(path))[0]
        try:
            if ext == ".csv" or ext == ".tsv":
                rows = read_csv(path)
                if rows:
                    devices.append(device_from_rows(rows, base))
            elif ext == ".xlsx":
                wb = openpyxl.load_workbook(path, data_only=True)
                for sn in wb.sheetnames:
                    rows = read_xlsx_sheet(path, sn)
                    if rows:
                        devices.append(device_from_rows(rows, base + ("_" + sn if len(wb.sheetnames) > 1 else "")))
            elif ext == ".json":
                devices.extend(read_json(path))
            elif ext in (".md", ".txt"):
                rows = read_markdown_table(path)
                if rows:
                    devices.append(device_from_rows(rows, base))
        except Exception as e:
            print(f"[警告] 解析 {os.path.basename(path)} 失败: {e}", file=sys.stderr)
    return devices


# ---------------------------------------------------------------------------
# 2. 自动排版引脚 (IC 式矩形符号)
# ---------------------------------------------------------------------------

def layout_device(dev, pin_length=20, spacing=20, x_pad=20, y_pad=20):
    """按引脚 Side 分组摆放; 未指定 Side 的自动分配到左/右两侧。
    返回后的每个 pin 都带 x,y,rotation。"""
    parts = OrderedDict()
    for p in dev.pins:
        parts.setdefault(p.part, []).append(p)

    # 为每个子库单独排版(子库=部件/单元)
    all_geom = []  # (part, minx, maxx, miny, maxy)
    for part, pins in parts.items():
        sides = OrderedDict()
        auto = []
        for p in pins:
            if p.side in ("L", "R", "T", "B"):
                sides.setdefault(p.side, []).append(p)
            else:
                auto.append(p)
        # 未指定方向的引脚: 均分到左/右
        n = len(auto)
        for i, p in enumerate(auto):
            p.side = "L" if i < (n + 1) // 2 else "R"
            sides.setdefault(p.side, []).append(p)
        # 给每侧按 order 排序(无 order 保持原序)
        for s, plist in sides.items():
            plist.sort(key=lambda q: (q.order if q.order is not None else 1e9))
        left, right = sides.get("L", []), sides.get("R", [])
        top, bottom = sides.get("T", []), sides.get("B", [])
        maxV = max(len(left), len(right))
        maxH = max(len(top), len(bottom))
        bodyW = max(40, (maxH + 1) * spacing)   # 至少 0.4 inch 宽
        bodyH = max(30, maxV * spacing)         # 至少 0.3 inch 高
        # 左右引脚
        for i, p in enumerate(left):
            y = (len(left) - 1) / 2.0 * spacing - i * spacing
            p.x = -bodyW / 2 - x_pad
            p.y = y
            p.rotation = SIDE_TO_ROTATION["L"]
        for i, p in enumerate(right):
            y = (len(right) - 1) / 2.0 * spacing - i * spacing
            p.x = bodyW / 2 + x_pad
            p.y = y
            p.rotation = SIDE_TO_ROTATION["R"]
        # 上下引脚
        for i, p in enumerate(top):
            x = (len(top) - 1) / 2.0 * spacing - i * spacing
            p.x = x
            p.y = bodyH / 2 + y_pad
            p.rotation = SIDE_TO_ROTATION["T"]
        for i, p in enumerate(bottom):
            x = (len(bottom) - 1) / 2.0 * spacing - i * spacing
            p.x = x
            p.y = -bodyH / 2 - y_pad
            p.rotation = SIDE_TO_ROTATION["B"]
        all_geom.append((part, -bodyW / 2, bodyW / 2, -bodyH / 2, bodyH / 2))
    dev._body = all_geom  # (part, minx,maxx,miny,maxy)
    return dev


# ---------------------------------------------------------------------------
# 3. 输出: 高级符号向导 Excel 模板
# ---------------------------------------------------------------------------

def write_wizard_xlsx(dev, out_path):
    wb = Workbook()
    ws = wb.active
    ws.title = "Info_SYM_" + (re.sub(r"[^\w\-]", "_", dev.name) or "symbol")[:20]
    ws.append(WIZARD_HEADER)
    layout_device(dev)
    side_order = {}
    for p in dev.pins:
        key = (p.part, p.side)
        side_order[key] = side_order.get(key, 0) + 1
        ws.append([
            p.part or "", p.side or "L", side_order[key],
            p.name, p.ptype, p.number, p.shape,
        ])
    for i, h in enumerate(WIZARD_HEADER, start=1):
        ws.column_dimensions[get_column_letter(i)].width = 18
    wb.save(out_path)


def _group_by_part(dev):
    d = OrderedDict()
    for p in dev.pins:
        d.setdefault(p.part, []).append(p)
    return d


# ---------------------------------------------------------------------------
# 4. 输出: 嘉立创EDA专业版 V3 符号文件 (JSON-Lines)
# ---------------------------------------------------------------------------

def _line(outer, inner):
    """构造 '外层||内层|' 一行"""
    o = json.dumps(outer, ensure_ascii=False, separators=(",", ":"))
    i = json.dumps(inner, ensure_ascii=False, separators=(",", ":"))
    return f"{o}||{i}|"


def write_symbol_json(dev, out_path):
    dev_uuid = uuid.uuid4().hex
    lines = []
    lines.append(_line({"type": "DOCHEAD", "ticket": 1},
                       {"docType": "SYMBOL", "client": "cli",
                        "uuid": dev_uuid, "version": "1", "user": {"uuid": dev_uuid}}))
    lines.append(_line({"type": "CANVAS", "ticket": 2, "id": "CANVAS"},
                       {"originX": 0, "originY": 0}))
    # PART: 每个子库一个 PART
    parts = _group_by_part(dev)
    ticket = 3
    part_ids = {}
    for part, pins in parts.items():
        pid = "pid" + uuid.uuid4().hex[:14]
        part_ids[part] = pid
        # 包围盒(按排版后的引脚估算)
        xs = [p.x for p in pins if p.x is not None]
        ys = [p.y for p in pins if p.y is not None]
        bbox = [min(xs) if xs else -40, max(ys) if ys else 0,
                max(xs) if xs else 40, min(ys) if ys else 0]
        lines.append(_line({"type": "PART", "ticket": ticket, "id": pid},
                           {"BBOX": bbox, "title": part}))
        ticket += 1
    # 元件级 ATTR: Symbol / Name(若有描述)
    first_pid = next(iter(part_ids.values()))
    for key, val, vis in (("Symbol", dev.name, False),
                          ("Name", "", False),
                          ("Description", dev.description, False)):
        if val or key == "Symbol":
            lines.append(_line({"type": "ATTR", "ticket": ticket, "id": "e" + str(ticket)},
                               {"partId": first_pid, "groupId": "", "locked": False,
                                "zIndex": 0.1, "parentId": "", "key": key, "value": val,
                                "keyVisible": vis, "valueVisible": vis,
                                "x": 0, "y": 0, "rotation": 0, "color": None,
                                "fillColor": None, "fontFamily": None, "fontSize": None,
                                "strikeout": None, "underline": None, "italic": None,
                                "fontWeight": None, "align": "CENTER_MIDDLE", "version": "2.0"}))
            ticket += 1
    # 引脚 + 其 Name/Number/Type 属性
    for part, pins in parts.items():
        pid = part_ids[part]
        for p in pins:
            pid_pin = "e" + str(ticket)
            lines.append(_line({"type": "PIN", "ticket": ticket, "id": pid_pin},
                               {"partId": pid, "groupId": "", "locked": False,
                                "zIndex": 2, "display": True,
                                "x": p.x, "y": p.y, "length": 20,
                                "rotation": p.rotation, "color": None,
                                "pinShape": p.json_shape}))
            ticket += 1
            for k, v, align in (("Pin Name", p.name, "CENTER_MIDDLE"),
                                ("Pin Number", p.number, "CENTER_MIDDLE"),
                                ("Pin Type", p.ptype, "CENTER_MIDDLE")):
                lines.append(_line({"type": "ATTR", "ticket": ticket, "id": "e" + str(ticket)},
                                   {"partId": pid, "groupId": "", "locked": False,
                                    "zIndex": 3, "parentId": pid_pin, "key": k, "value": v,
                                    "keyVisible": False, "valueVisible": False,
                                    "x": p.x, "y": p.y, "rotation": 0, "color": None,
                                    "fillColor": None, "fontFamily": None, "fontSize": None,
                                    "strikeout": None, "underline": None, "italic": None,
                                    "fontWeight": None, "align": align, "version": "2.0"}))
                ticket += 1
    # 矩形封装体
    for part, minx, maxx, miny, maxy in (dev._body if hasattr(dev, "_body") else []):
        pid = part_ids[part]
        lines.append(_line({"type": "RECT", "ticket": ticket, "id": "e" + str(ticket)},
                           {"partId": pid, "groupId": "", "locked": False, "zIndex": 1,
                            "dotX1": minx, "dotY1": maxy, "dotX2": maxx, "dotY2": miny,
                            "radiusX": 0, "radiusY": 0, "rotation": 0,
                            "strokeColor": None, "strokeStyle": 0, "fillColor": "",
                            "strokeWidth": None, "fillStyle": 0}))
        ticket += 1
    # META 文档元数据
    lines.append(_line({"type": "META", "ticket": ticket, "id": "META"},
                       {"title": dev.name, "description": dev.description,
                        "tags": [None, None], "docType": 2, "source": ""}))
    with open(out_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")


# ---------------------------------------------------------------------------
# 5. 输出: SVG 预览图(纯标准库, 直观查看符号)
# ---------------------------------------------------------------------------

def render_svg(dev, out_path, scale=4.0):
    """把排版后的符号渲染成 SVG 预览图。scale: 每个 0.01inch 单位对应像素。"""
    layout_device(dev)
    xs = [p.x for p in dev.pins if p.x is not None] or [-40, 40]
    ys = [p.y for p in dev.pins if p.y is not None] or [-40, 40]
    minx, maxx, miny, maxy = min(xs), max(xs), min(ys), max(ys)
    pad = 30
    W = int((maxx - minx + 2 * pad) * scale)
    H = int((maxy - miny + 2 * pad) * scale)
    def px(x, y):
        return ((x - minx + pad) * scale, (maxy - y + pad) * scale)  # y翻转
    parts = []
    # 封装体矩形
    for part, bx1, bx2, by1, by2 in (dev._body if hasattr(dev, "_body") else []):
        x1, y1 = px(bx1, by2); x2, y2 = px(bx2, by1)
        parts.append(f'<rect x="{x1:.1f}" y="{y1:.1f}" width="{x2-x1:.1f}" height="{y2-y1:.1f}" fill="none" stroke="#000" stroke-width="2"/>')
    # 引脚: 从连接端点向封装体画线 + 名称/编号
    for p in dev.pins:
        if p.x is None:
            continue
        ex, ey = px(p.x, p.y)
        # 依据 rotation 向内(length)延伸
        if p.rotation == 0:   sx, sy = px(p.x - 20, p.y)
        elif p.rotation == 90: sx, sy = px(p.x, p.y + 20)
        elif p.rotation == 180:sx, sy = px(p.x + 20, p.y)
        else:                 sx, sy = px(p.x, p.y - 20)
        parts.append(f'<line x1="{ex:.1f}" y1="{ey:.1f}" x2="{sx:.1f}" y2="{sy:.1f}" stroke="#000" stroke-width="2"/>')
        # 名称文本(放连接端点外侧)
        tx, ty = ex, ey
        if p.rotation == 180: tx, ty = ex + 6, ey
        elif p.rotation == 0: tx, ty = ex - 6, ey
        elif p.rotation == 90: tx, ty = ex, ey - 6
        else:                 tx, ty = ex, ey + 6
        parts.append(f'<text x="{tx:.1f}" y="{ty:.1f}" font-size="8" fill="#000" dominant-baseline="middle" text-anchor="middle">{p.name}</text>')
        parts.append(f'<text x="{ex:.1f}" y="{ey+12:.1f}" font-size="7" fill="#666" dominant-baseline="middle" text-anchor="middle">{p.number}</text>')
    svg = ('<?xml version="1.0" encoding="UTF-8"?>\n'
           f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}">\n'
           '<rect width="100%" height="100%" fill="#fff"/>\n'
           + "\n".join(parts) + "\n</svg>\n")
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(svg)


# ---------------------------------------------------------------------------
# 主流程
# ---------------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser(description="嘉立创EDA专业版原理图元件符号自动生成")
    ap.add_argument("folder", help="器件数据文件所在文件夹")
    ap.add_argument("--out", default="", help="输出目录(默认: 数据文件夹下 lceda_symbol_output)")
    ap.add_argument("--pin-length", type=int, default=20, help="引脚长度, 0.01inch, 默认20")
    args = ap.parse_args()

    if not os.path.isdir(args.folder):
        print(f"[错误] 文件夹不存在: {args.folder}")
        sys.exit(1)
    out = args.out or os.path.join(args.folder, "lceda_symbol_output")
    wizard_dir = os.path.join(out, "wizard")
    json_dir = os.path.join(out, "symbol_json")
    preview_dir = os.path.join(out, "preview")
    os.makedirs(wizard_dir, exist_ok=True)
    os.makedirs(json_dir, exist_ok=True)
    os.makedirs(preview_dir, exist_ok=True)

    devices = parse_inputs(args.folder)
    if not devices:
        print("[错误] 未在文件夹中解析到任何器件/引脚表。")
        print("      支持的格式: .csv/.tsv/.xlsx/.xls/.json/.md/.txt")
        print("      表格需包含表头: 引脚名称/引脚编号/引脚类型(或英文 Pin Name/Pin Number/Pin Type 等)")
        sys.exit(2)

    manifest = []
    for i, dev in enumerate(devices, 1):
        layout_device(dev, pin_length=args.pin_length)
        safe = re.sub(r"[^\w\-]+", "_", dev.name) or f"device_{i}"
        xlsx_path = os.path.join(wizard_dir, f"{safe}.xlsx")
        json_path = os.path.join(json_dir, f"{safe}.json")
        svg_path = os.path.join(preview_dir, f"{safe}.svg")
        write_wizard_xlsx(dev, xlsx_path)
        write_symbol_json(dev, json_path)
        render_svg(dev, svg_path)
        manifest.append({"index": i, "name": dev.name, "pins": len(dev.pins),
                         "wizard": xlsx_path, "json": json_path, "preview": svg_path})
        print(f"[OK] {i}. {dev.name}  引脚数={len(dev.pins)}")
        print(f"      向导模板: {xlsx_path}")
        print(f"      V3符号:   {json_path}")
        print(f"      预览图:   {svg_path}")

    # 汇总清单
    manifest_path = os.path.join(out, "manifest.json")
    with open(manifest_path, "w", encoding="utf-8") as f:
        json.dump(manifest, f, ensure_ascii=False, indent=2)
    print(f"\n完成! 共生成 {len(devices)} 个元件符号。")
    print(f"产物目录: {out}")
    print(f"清单: {manifest_path}")


if __name__ == "__main__":
    main()
