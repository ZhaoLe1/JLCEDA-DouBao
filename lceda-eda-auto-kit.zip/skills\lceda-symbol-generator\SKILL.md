---
name: lceda-symbol-generator
description: 根据一个文件夹里的器件数据文件(Excel/CSV/JSON/Markdown 引脚表)自动生成嘉立创EDA专业版(LCEDA Pro)的原理图元件符号。当用户需要把器件引脚表或数据手册信息自动变成原理图符号、批量创建元件库、或提供某个文件夹的引脚数据文件要求自动出符号时使用。产物为 ①高级符号向导可导入的 Excel 模板(保底路径) ②V3 JSON-Lines 符号文件(进阶) ③SVG 预览图。触发词含 嘉立创EDA/立创EDA/LCEDA/原理图符号/元件库/引脚表/高级符号向导/画元件。
---

# LCEDA 原理图元件符号自动生成

把一个文件夹里的器件引脚数据(Excel/CSV/JSON/Markdown 表)批量转换成
**嘉立创EDA专业版可用的原理图符号**: 自动解析元件名与引脚, 自动排版引脚,
输出可导入的向导模板 + V3 符号文件 + 预览图。

详细格式事实(坐标单位、引脚方向↔rotation、Pin Type/Shape 枚举、V3 结构)见
`references/lceda-symbol-format.md` —— 生成前应先读它。

## 工作流

1. **确认输入文件夹**: 找用户指定的器件数据文件夹(或让用户提供)。若没有现成
   数据, 询问用户; 若用户给了数据手册 PDF, 先用 PDF 技能把引脚表提成 CSV/JSON 再继续。
2. **运行生成器**:

   ```bash
   python <本技能目录>/scripts/generate_symbols.py <数据文件夹> [--out <输出目录>] [--pin-length 20]
   ```

   脚本会自动: 扫描文件夹 → 解析每个器件 → 自动排版引脚 → 在输出目录(默认
   `<数据文件夹>/lceda_symbol_output`)下生成 `wizard/*.xlsx`、`symbol_json/*.json`、`preview/*.svg`。
3. **查看预览并核对**: 打开 `preview/*.svg`(可转 PNG)让用户确认符号外观与引脚方向。
4. **交付并指导导入(保底路径)**: 告诉用户在嘉立创EDA专业版中
   `顶部菜单 -> 工具 -> 高级符号向导 -> 导入`, 选择 `wizard/*.xlsx`,
   向导自动生成符号; 再补绑定封装/3D 模型即可使用。
5. 若用户要的是自动化 JSON 路径, 交付 `symbol_json/*.json` 并说明其 V3 格式。

## 输入数据格式(自动识别)

| 文件类型 | 说明 |
|---------|------|
| Excel/CSV/TSV | 引脚表, 首行表头; 表头中英同义词均可(引脚名称/Pin Name、引脚编号/Pin Number、引脚类型/Pin Type、方向/Side、引脚形状/Pin Shape、部件/Part、序号/Order、元件名/Device) |
| JSON | 对象或数组: `{"name","description","pins":[{"name","number","ptype","side","shape","part"}]}` |
| Markdown/文本 | 管道表格 `| a | b |` |

- 元件名缺省时取文件名; 也可用"元件名/Device"列显式指定。
- 引脚可选填 `side`(L/T/R/B)控制方向, 不填则自动左右均分。
- 引脚类型缺省 `Passive`, 形状缺省 `None`。

## 关键输出与导入方式

产物都在输出目录下, 三个子目录:

- **`wizard/*.xlsx`** —— 高级符号向导导入模板(保底、最可靠)。
  在专业版 `工具 -> 高级符号向导 -> 导入` 选择即可。
- **`symbol_json/*.json`** —— V3 JSON-Lines 符号文件(进阶/自动化)。
- **`preview/*.svg`** —— 符号排版预览图。

## 校验与注意事项

- 生成后务必抽查: 打开 `preview` 确认引脚数量/方向与输入一致; 打开
  `wizard/*.xlsx` 确认列顺序是 `Part/Side/Order/Pin Name/Pin Type/Pin Number/Pin Shape`。
- 引脚方向与 rotation 映射必须用 `L=0, T=90, R=180, B=270`(见参考文档 §2)。
- 数据手册 PDF 的引脚表解析不可靠 —— 需先人工核对提取结果再生成。
- 依赖 `openpyxl`; 脚本缺库时会尝试自动 `pip install openpyxl`。
